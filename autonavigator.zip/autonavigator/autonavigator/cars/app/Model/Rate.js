'use strict'

const Lucid = use('Lucid')

class Rate extends Lucid {
    car () {
        return this.belongsTo('App/Model/Car')
    }
}

module.exports = Rate
