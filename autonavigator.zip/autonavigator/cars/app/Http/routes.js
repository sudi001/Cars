'use strict'

/*
|--------------------------------------------------------------------------
| Router
|--------------------------------------------------------------------------
|
| AdonisJs Router helps you in defining urls and their actions. It supports
| all major HTTP conventions to keep your routes file descriptive and
| clean.
|
| @example
| Route.get('/user', 'UserController.index')
| Route.post('/user', 'UserController.store')
| Route.resource('user', 'UserController')
*/

const Route = use('Route')

Route.get('/', 'CarController.index2')
Route.get('/main', 'CarController.index')
Route.get('/layout', 'CarController.index2')
Route.get('/carCategory', 'CarController.index3')
Route.post('/cars/:id', 'CarController.doEdit').middleware('auth')
Route.get('/cars/:id', 'CarController.show')


Route.get('/register', 'UserController.register')
Route.get('/login', 'UserController.login')
Route.get('/login', 'UserController.login')
Route.post('/register', 'UserController.doRegister')
Route.post('/login', 'UserController.doLogin')
Route.get('/logout', 'UserController.doLogout')
