'use strict'

const Database = use('Database')
const Category = use('App/Model/Category')
const Car = use('App/Model/Car')
const Validator = use('Validator')
const Rate = use('App/Model/Rate')
const User = use('App/Model/User')

class CarController {

  * index(request, response) {
    // const categories = yield Database.from('categories').select('*');
    // response.send(categories)

    const cars = yield Car.all()
    yield response.sendView('main', {
      name: '',
      cars: cars.toJSON()
    })  
  }
  * index2(request, response) {
    // const categories = yield Database.from('categories').select('*');
    // response.send(categories)

    const categories = yield Category.all()

    for(let category of categories) {
      const cars = yield category.cars().limit(3).fetch();
      category.topCars = cars.toJSON();
    }

    yield response.sendView('layout', {
      name: '',
      categories: categories.toJSON()
    })  
  }
   * index3(request, response) {
    // const categories = yield Database.from('categories').select('*');
    // response.send(categories)

    const categories = yield Category.all()

    for(let category of categories) {
      const cars = yield category.cars().limit(3).fetch();
      category.topCars = cars.toJSON();
    }

    yield response.sendView('carCategory', {
      name: '',
      categories: categories.toJSON()
    })  
  }


* doEdit (request, response) {
  const user_id = request.param('user_id')
  const rateData = request.except('_csrf');
      const rules = {
      komment: 'required',
      rate: 'required',
      user_name: 'required'
    };

    const validation = yield Validator.validateAll(rateData, rules)

    if (validation.fails()) {
      yield request
        .withAll()
        .andWith({errors: validation.messages()})
        .flash()
      response.redirect('back')
      return
    }
    const id = request.param('id')
    rateData.user_name = request.currentUser.username
    rateData.car_id= id
    const rates = yield Rate.create(rateData)

    response.redirect("/cars/"+ id )
  }



  

  * show (request, response) {
    const id = request.param('id');
    const car = yield Car.find(id);
    yield car.related('category').load();
    // response.send(car.toJSON())
    const rates = yield Rate.all()

    yield response.sendView('carShow', {
      rates: rates.toJSON(),
      currentId: id,
      car: car.toJSON()
    })
  }

  
}

module.exports = CarController
