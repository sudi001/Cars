'use strict'


const Lucid = use('Lucid')

class Car extends Lucid {
  category () {
    return this.belongsTo('App/Model/Category')
  }
    rate () {
      return this.belongsTo('App/Model/Rate')
    }
}

module.exports = Car
